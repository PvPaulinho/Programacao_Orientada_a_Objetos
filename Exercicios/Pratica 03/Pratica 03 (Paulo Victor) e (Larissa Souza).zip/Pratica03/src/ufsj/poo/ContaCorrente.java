package ufsj.poo;

import java.util.Scanner;

import ufsj.poo.Conta.conta;

public class ContaCorrente extends Contas implements conta {

	Scanner sc = new Scanner(System.in);
	int c = 0;
	public String no[];
	public int nu[];
	public float s[];

	public void CriarConta() {
		System.out.println("Digite o nome: ");
		no[c] = sc.next();
		System.out.println("Digite o numero: ");
		nu[c] = sc.nextInt();
		System.out.println("Digite o saldo: ");
		s[c] = sc.nextFloat();
		c++;
	}

	public void sacar() {
		float vs;
		System.out.println("Digite o valor do saque desejado: ");
		vs = sc.nextFloat();
		System.out.println("Digite o numero da conta: ");
		int nc;
		nc = sc.nextInt();
		for (int i = 0; i < c; i++) {
			if (nc == nu[c]) {
				if (s[c] > vs) {
					s[c] = (float) (s[c] * 0.95);
					System.out.println("O saldo restante e de: " + s[c]);
				} 
				else {
					System.out.println("Saldo insuficiente.");
				}
			}
			else {
				System.out.println("Numero invalido.");
			}
		}
	}

	public void ConferirSaldo() {
		int nc;
		System.out.println("Digite o numero da conta: ");
		nc = sc.nextInt();
		for (int i = 0; i < c; i++) {
			if (nc == nu[c]) {
				System.out.println("O saldo da conta e: " + s[c]);
			}
			else {
				System.out.println("Numero invalido.");
			}
		}
	}

	public void depositar() {
		int nc;
		float vd;
		System.out.println("Digite o numero da conta: ");
		nc = sc.nextInt();
		for (int i = 0; i < c; i++) {
			if (nc == nu[c]) {
				System.out.println("Digite o valor a ser depositado: ");
				vd = sc.nextFloat();
				s[c] = s[c] + vd;
				System.out.println("O seu novo saldo e de: " + s[c]);
			} 
			else {
				System.out.println("Numero invalido.");
			}
		}
	}
	
	public void imprimir(){
		for (int i=0;i<c;i++){
			System.out.println ("Conta " + c + ": " + "\nNome: " + no[c] + "\nNumero da conta: " + nu[c] + "\nSaldo: " + s[c] + "\n");
		}
	}
}