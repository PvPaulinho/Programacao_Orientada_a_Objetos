package ufsj.poo;

public abstract class Conta {

	interface conta{
	
	public void sacar ();
	public void depositar ();
}
}