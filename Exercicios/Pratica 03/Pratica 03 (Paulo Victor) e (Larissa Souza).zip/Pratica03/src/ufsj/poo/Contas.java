package ufsj.poo;

public abstract class Contas {

	private String NomeDoTitular;
	private int numero;
	private float saldo;
	
	public String getNomeDoTitular() {
		return NomeDoTitular;
	}
	public void setNomeDoTitular(String nomeDoTitular) {
		this.NomeDoTitular = nomeDoTitular;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public float getSaldo() {
		return saldo;
	}
	public void setSaldo(float saldo) {
		this.saldo = saldo;
	}
	
	
}
