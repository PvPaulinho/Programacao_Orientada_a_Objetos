package ufsj.poo;

import java.util.Scanner;

public class Banco {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int menu;
		System.out.println("-Digitar 1 - Criar Conta Corrente\n-Digitar 2 - Criar Conta Poupan�a\n-Digitar 3 - Saque\n-Digitar 4 - Saldo\n-Digitar 5 - Deposito\n-Digitar 6 - Imprimir Contas\n-Digitar 7 - Sair");
		menu = sc.nextInt();
		switch (menu) {
		case 1:
			ContaCorrente();
			break;
		case 2:
			Poupan�a();
			break;
		case 3:
			Saque();
			break;
		case 4:
			Saldo();
			break;
		case 5:
			Deposito();
			break;
		case 6:
			ImprimirContas();
			break;
		case 7:
			break;
		}
	}
	public static void ContaCorrente(){
		ContaCorrente contaC = new ContaCorrente();
		contaC.CriarConta();
	}
	public static void Poupan�a(){
		Poupan�a contaP = new Poupan�a();
		contaP.CriarConta();
	}
	public static void Saque(){
		Scanner sc = new Scanner(System.in);
		int ns;
		System.out.println ("Digite 1 para conta corrente ou 2 para poupan�a: ");
		ns=sc.nextInt();
		if (ns==1){
			ContaCorrente contaC = new ContaCorrente();
			contaC.sacar();
		}
		if (ns==2){
			Poupan�a contaP = new Poupan�a();
			contaP.sacar();
		}
	}
	public static void Saldo(){
		Scanner sc = new Scanner(System.in);
		int ns;
		System.out.println ("Digite 1 para conta corrente ou 2 para poupan�a: ");
		ns=sc.nextInt();
		if (ns==1){
			ContaCorrente contaC = new ContaCorrente();
			contaC.ConferirSaldo();
		}
		if (ns==2){
			Poupan�a contaP = new Poupan�a();
			contaP.ConferirSaldo();
		}
	}
	public static void Deposito(){
		Scanner sc = new Scanner(System.in);
		int ns;
		System.out.println ("Digite 1 para conta corrente ou 2 para poupan�a: ");
		ns=sc.nextInt();
		if (ns==1){
			ContaCorrente contaC = new ContaCorrente();
			contaC.depositar();
		}
		if (ns==2){
			Poupan�a contaP = new Poupan�a();
			contaP.depositar();
		}
	}
	public static void ImprimirContas(){
		Scanner sc = new Scanner(System.in);
		int ns;
		System.out.println ("Digite 1 para conta corrente ou 2 para poupan�a: ");
		ns=sc.nextInt();
		if (ns==1){
			ContaCorrente contaC = new ContaCorrente();
			contaC.imprimir();
		}
		if (ns==2){
			Poupan�a contaP = new Poupan�a();
			contaP.imprimir();
		}
	}
}
