package Exercicio16;

import java.util.Scanner;

public class Exercicio16 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		float n[] = new float[10];
		float x;
		for (int i=0;i<10;i++){
			System.out.println ("Digite um numero: ");
			n[i]=sc.nextInt();
		}
		for (int i=0;i<9;i++){
			for (int u=i+1;u<10;u++){
				if (n[i]>n[u]){
					x=n[i];
					n[i]=n[u];
					n[u]=x;
				}
			}
		}
		for (int i=0;i<10;i++){
			System.out.println (n[i]);
		}
	}

	}
