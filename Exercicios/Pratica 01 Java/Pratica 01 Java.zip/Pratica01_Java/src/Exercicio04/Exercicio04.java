package Exercicio04;

import java.util.Scanner;

public class Exercicio04 {

	public static void main(String[] args) {
		float p ,t;
		Scanner sc = new Scanner (System.in);
		System.out.println("Informe o peso: ");
		p= sc.nextFloat();
		System.out.println("Informe o tamanho: ");
		t = sc.nextFloat();
	
		float imc;
		imc= imc(p,t);
		if(imc<18.5) {
			System.out.println("O seu imc e: " + imc);
			System.out.println("Voce esta abaixo do peso.");
		}
		if((imc>18.6) &&(imc<24.9) ){
			System.out.println(imc + ",� seu imc e");
			System.out.println("Voce esta saudavel.");
		}
		if((imc>25) &&(imc<29.9) ) {
			System.out.println("O seu imc e: " + imc);
			System.out.println("Voce esta com execesso de peso.");
		}
		if((imc>30) &&(imc<34.9) ) {
			System.out.println("O seu imc e: " + imc);
			System.out.println("Voce esta com obesidade grau 1.");
		}
		if((imc>35) &&(imc<39.9) ){
			System.out.println("O seu imc e: " + imc);
			System.out.println("Voce esta com obesidade grau 2.");
		}
		if(imc>40) {
			System.out.println("O seu imc e: " + imc);
			System.out.println("Voce esta com obesidade morbida.");
		}
	}
	static float imc(float p ,float t) {
		return p/(t*t);
	}
}
