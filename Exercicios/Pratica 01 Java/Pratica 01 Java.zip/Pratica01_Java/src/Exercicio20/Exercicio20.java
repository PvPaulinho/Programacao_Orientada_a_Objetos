package Exercicio20;

import java.util.Scanner;

public class Exercicio20 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		double x;
		
		for (int i=1;i>0;i++){
			System.out.println ("Se desejar sair dizgite 0.\nOu informe um numero: ");
			x=sc.nextDouble();
			if (x==0){
				break;
			}
			if (x!=0){
				int in;
				double f;
				in=(int) x;
				f=x-in;
				System.out.println ("O inteiro do numero e: "+in+" e o fracionario e: "+f);
			}
		}
	}

}
