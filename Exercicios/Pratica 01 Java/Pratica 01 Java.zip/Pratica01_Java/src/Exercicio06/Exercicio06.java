package Exercicio06;

import java.util.Scanner;

public class Exercicio06 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int km, l, u=1;
		float m = 0;
		
		while (u == 1) {
			System.out.println("Digite os km: ");
			km = sc.nextInt();
			System.out.println("Digite quantos litros: ");
			l = sc.nextInt();
			m = m + (km / l);
			System.out.println("A media e = " + m);
			System.out.println("Para continuar digite 1.");
			u = sc.nextInt();
		}
	}
}
