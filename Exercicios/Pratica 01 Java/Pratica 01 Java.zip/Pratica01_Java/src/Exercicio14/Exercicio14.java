package Exercicio14;

import java.util.Scanner;

public class Exercicio14 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		int v2[] = new int[15];
		int v1[]={2,5,7};
		int c=0;
		for (int i=0;i<15;i++){
			System.out.println ("Digite um numero para o segundo vetor: ");
			v2[i]=sc.nextInt();
		}
		for (int i=0;i<3;i++){
			if (c>0){
				break;
			}
			for (int u=0;u<13;u++){
				if (v1[i]==v2[u] && v1[i+1]==v2[u+1] && v1[i+2]==v2[u+2]){
					System.out.println ("O primeiro vetor esta contido dentro do segundo apartir da posi��o "+u);
					c++;
				}
			}
		}
	}
}
