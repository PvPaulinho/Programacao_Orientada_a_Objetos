package Exercicio12;

import java.util.Scanner;

public class Exercicio12 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		int n[] = new int[15];
		int n1;
		int x;
		for (int i=0;i<15;i++){
			System.out.println ("Digite um numero: ");
			n[i]=sc.nextInt();
		}
		System.out.println ("Digite um numero para multiplicar os demais: ");
		n1=sc.nextInt();
		for (int i=0;i<15;i++){
			n[i]=n[i]*n1;
		}
		for (int i=0;i<14;i++){
			for (int u=i+1;u<15;u++){
				if (n[i]>n[u]){
					x=n[i];
					n[i]=n[u];
					n[u]=x;
				}
			}
		}
		for (int i=0;i<15;i++){
			System.out.println (n[i]);
		}
	}

}
