package Exercicio18;

import java.util.Scanner;

public class Exercicio18 {

	static float convercao (float r,float v){
		float d;
		d=r*v;
		return d;
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		float v;
		
		System.out.println ("Informe quantos Reias vale 1 Dolar: ");
		v=sc.nextFloat();
		
		int m;
		float vf;
		float r;
		for (int i=1;i>0;i++){
			System.out.println ("Digite 1 para informar o valor em Reais a ser convertido ou digite 2 para sair: ");
			m=sc.nextInt();
			if (m==1){
				System.out.println ("Digite o valor em Reais a ser convertido: ");
				r=sc.nextFloat();
				vf=convercao(r,v);
				System.out.println ("O valor em Dolares e: "+vf);
			}
			if (m==2){
				break;
			}
		}
		
	}

}
