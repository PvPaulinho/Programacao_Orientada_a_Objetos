package Exercicio24;

import java.util.Scanner;

public class Exercicio24 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		double v1[] = new double[10];
		double v2[] = new double[10];
		int c=0;
		
		for (int i=0;i<10;i++){
			System.out.println ("Digite um valor para o primeiro vetor: ");
			v1[i]=sc.nextDouble();
			System.out.println ("Digite um valor para o segundo vetor: ");
			v2[i]=sc.nextDouble();
		}
		for (int i=0;i<10;i++){
			for (int u=0;u<10;u++){
				if (v1[i]==v2[u]){
					c++;
					break;
				}
			}
		}
		System.out.println ("Tem " + c + " numeros ao mesmo tempo nos dois vetores.");
	}

}
