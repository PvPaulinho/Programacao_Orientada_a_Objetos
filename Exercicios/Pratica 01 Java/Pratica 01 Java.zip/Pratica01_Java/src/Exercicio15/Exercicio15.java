package Exercicio15;

import java.util.Scanner;

public class Exercicio15 {

	static float quadrado (float l){
		float q;
		q=l*l;
		return q;
	}
	
	static float circulo (float r){
		float c;
		c=(float)(r*r*Math.PI);
		return c;
	}
	
	static float triangulo (float b,float a){
		float t;
		t=b*a/2;
		return t;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		int menu;
		float l,r,b,a;
		float aq,ac,at;

		for (int i=1;i>0;i++){
			System.out.println ("1 - Calcular a �rea de um quadrado\n2 � Calcular a �rea de um c�rculo\n3 � Calcular a �rea de um tri�ngulo\n4 � Sair");
			menu=sc.nextInt();
			if (menu==1){
				System.out.println ("Informe o lado do quadrado: ");
				l=sc.nextFloat();
				aq=quadrado(l);
				System.out.println ("A area do quadrado e: "+aq);
			}
			if (menu==2){
				System.out.println ("Informe o raio do circulo: ");
				r=sc.nextFloat();
				ac=circulo(r);
				System.out.println ("A area do circulo e: "+ac);
			}
			if (menu==3){
				System.out.println ("Informe a base do triangulo: ");
				b=sc.nextFloat();
				System.out.println ("Informe a altura do triangulo: ");
				a=sc.nextFloat();
				at=triangulo(b,a);
				System.out.println ("A area do triangulo e: "+at);
			}
			if (menu==4){
				break;
			}
		}
	}

}
