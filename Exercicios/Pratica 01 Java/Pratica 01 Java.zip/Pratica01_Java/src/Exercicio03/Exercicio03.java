package Exercicio03;

import java.util.Scanner;

public class Exercicio03 {

	public static void main(String[] args) {
		
		float salario;
		float soma=0;
		float media;
		int c=0;
		
		Scanner sc = new Scanner (System.in);
		
		boolean x = true;
		while (x){
			System.out.println ("Digite um sal�rio: ");
			salario = sc.nextFloat();
			if (salario>=0){
				soma=soma+salario;
				c++;
			}
			if (salario<0){
				media=soma/c;
				System.out.println ("A media dos salarios e: " + media);
				x = false;
			}
		}
		
	}

}