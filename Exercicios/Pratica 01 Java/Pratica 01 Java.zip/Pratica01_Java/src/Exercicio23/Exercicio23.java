package Exercicio23;

import java.util.Scanner;

public class Exercicio23 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		int v[] = new int[10];
		int n;
		int c=0;
		
		for (int i=0;i<10;i++){
			System.out.println ("Digite um numero para o vetor: ");
			v[i]=sc.nextInt();
		}
		for (int i=0;i<3;i++){
			if (i==0){
				System.out.println ("Digite um numero para tentar acertar um dos numeros do vetor anterior: ");
				n=sc.nextInt();
				for (int u=0;u<10;u++){
					if (n==v[u]){
						c++;
					}
				}
				if (c>0){
					break;
				}
			}
			if (i==1){
				System.out.println ("Digite um outro numero: ");
				n=sc.nextInt();
				for (int u=0;u<10;u++){
					if (n==v[u]){
						c++;
					}
				}
				if (c>0){
					break;
				}
			}
			if (i==2){
				System.out.println ("Digite um outro numero: ");
				n=sc.nextInt();
				for (int u=0;u<10;u++){
					if (n==v[u]){
						c++;
					}
				}
				if (c>0){
					break;
				}
			}
		}
		if (c>0){
			System.out.println ("Voce conseguiu acertar um dos numeros.");
		}
		if (c==0){
			System.out.println ("Voce nao conseguiu acertar nenhum dos numeros nas 3 tentivas.");
		}
	}

}
