package Exercicio05;

import java.util.Scanner;

public class Exercicio05 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int u = 1;
		float a, b, c;
		
		while (u == 1) {
			System.out.println("Digite a: ");
			a = sc.nextFloat();
			System.out.println("Digite b: ");
			b = sc.nextFloat();
			System.out.println("Digite c: ");
			c = sc.nextFloat();
			float d = delta(a, b, c);
			raizes(d, b, a);
			System.out.println("A = " + a + "B = " + b + "C = " + c + "Delta = " + d);
			System.out.println("Para continuar aperte 1");
			u = sc.nextInt();
		}
	}
	
	static float delta(float a,float b,float c){
		return ((b*b)-(4*a*c));
	}
	static void raizes(float delta,float b,float a){
		float x1,x2;
		if (delta<0) {
			System.out.println("Nao tem raiz real.");	
		}
		else {if(delta==0)
		{
			x2=x1=-b/(2*a);
			System.out.println("A raiz e: "+ x1);	
		}else {
			x1=(float) (-b/(2*a) + Math.sqrt(delta));
			System.out.println("A primeira raiz e: "+ x1);
			x2=(float) (-b/(2*a) - Math.sqrt(delta));
			System.out.println("A segunda raiz e: "+ x2);
		}	
		}
		}
}
