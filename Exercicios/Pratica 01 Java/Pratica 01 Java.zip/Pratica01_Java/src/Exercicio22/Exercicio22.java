package Exercicio22;

import java.util.Scanner;

public class Exercicio22 {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		int v[] = new int [9];
		int s=0;
		int c=0;
		
		System.out.println ("Preencha os 8 primeiros numeros do vetor com os numeors '1' ou '0': ");
		for (int i=0;i<8;i++){
			c++;
			System.out.println (c+" Numero: ");
			v[i]=sc.nextInt();
			s=s+v[i];
		}
		if (s%2==0){
			v[8]=0;
		}
		if (s%2!=0){
			v[8]=1;
		}
		System.out.println ("O vetor ficou: ");
		for (int i=0;i<9;i++){
			System.out.println (v[i]);
		}
	}

}
