package Exercicio09;
import java.util.Scanner;
public class Exercicio09 {

	public static float Celsius (float t){
		float celsius;
		float a=(float)0.55;
		celsius=a*(t-32);
		return celsius;
	}
	
	public static float Fahrenheit (float t){
		float fahrenheit;
		fahrenheit=9/5*t+32;
		return fahrenheit;
	}
	
	public static void main(String[] args) {
		
		float t;
		float r;
		int x;
		
		Scanner sc = new Scanner (System.in);
		
		System.out.println ("Informe uma temperatura: ");
		t=sc.nextFloat();
		System.out.println ("Digite 1 para converter de Fahrenheit para Celsius ou Digite 2 para converter de Celsius para Fahrenheit.");
		x=sc.nextInt();
		if (x==1){
			r=Celsius(t);
			System.out.println ("A temperatura em Celsius e: " + r);
		}
		if (x==2){
			r=Fahrenheit(t);
			System.out.println ("A temperatura em Fahrenheit e: " + r);
		}
		if (x!=1 && x!=2){
			System.out.println ("Numero incorreto informado.");
		}
	}

}
