package Exercicio17;

import java.util.Random;
import java.util.Scanner;

public class Exercicio17 {

	static int aleat(){
		Random r = new Random();
		int X = r.nextInt(101);
		return X;
	}
	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		int c=0;
		int m;
		int n;
		int x=aleat();
		
		for (int i=1;i>0;i++){
			System.out.println ("Digite 1 para tentar adivinhar o numero ou digite 2 para desistir: ");
			m=sc.nextInt();
			if (m==1){
				System.out.println ("Digite o numero escolhido: ");
				n=sc.nextInt();
				c++;
				if (n<x){
					System.out.println ("O numero digitado e menor.");
				}
				if (n>x){
					System.out.println ("O numero digitado e maior.");
				}
				if (n==x){
					System.out.println ("Voce acertou o numero.");
					System.out.println ("Voce usou "+c+" tentativas para acertar o numero.");
					break;
				}
			}
			if (m==2){
				System.out.println ("Voce desistiu na tentativa de numero "+c);
				break;
			}
		}
	}
}
