package Exercicio08;

import java.util.Scanner;

public class Exercicio08 {
	
	public static double hipotenusa (double b, double c){
		
		double hipotenusa;
		double a;
		a=(b*b)+(c*c);
		hipotenusa=Math.sqrt(a);
		return hipotenusa;
	}

	public static void main(String[] args) {
		
		double b;
		double c;
		double h;
		
		Scanner sc = new Scanner (System.in);
		
		System.out.println ("Digite o valor para o primeiro cateto: ");
		b = sc.nextDouble();
		
		System.out.println ("Digite o valor para o segundo cateto: ");
		c = sc.nextDouble();
		
		h =hipotenusa(b,c);
		
		System.out.println ("A hipotenusa e igual a: " + h);
	}

}
