package Exercicio07;

import java.util.Scanner;

public class Exercicio07 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		float ht,vh,nd,d,s;
		
		System.out.println ("Digite as horas trabalhadas: ");
		ht=sc.nextFloat();
		System.out.println ("Digite o valor da hora trabalhada: ");
		vh=sc.nextFloat();
		System.out.println ("Digite o numero de dependetes: ");
		nd=sc.nextFloat();
		System.out.println ("Digite o desconto: ");
		d=sc.nextFloat();
		
		s=ht*vh+(50*nd)-d;
		System.out.println ("O salario e: " + s);
	}

}
