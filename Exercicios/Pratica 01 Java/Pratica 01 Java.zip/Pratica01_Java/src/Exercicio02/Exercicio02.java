package Exercicio02;

import java.util.Scanner;

public class Exercicio02 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		float VP;
		float J;
		int n;
		float VF;
		float r=1;
		
		System.out.println ("Digite o valor que deseja aplicar: ");
		VP = sc.nextFloat();
		
		System.out.println ("Digite o valor do juros: ");
		J = sc.nextFloat();
		
		System.out.println ("Digite a quantidade de meses que o dinheiro ficara aplicado: ");
		n = sc.nextInt();
		
		for (int i=0; i<n; i++){
			r = (1+J)*r;
		}
		VF = VP*r;
		
		System.out.println ("No final tera um valor de: " + VF);
		
	}
	}
