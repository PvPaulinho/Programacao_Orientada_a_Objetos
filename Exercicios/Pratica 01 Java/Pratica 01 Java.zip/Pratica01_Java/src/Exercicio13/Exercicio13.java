package Exercicio13;

import java.util.Scanner;

public class Exercicio13 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		int n[] = new int[10];
		int x=0;
		int z;
		int c=0;
		for (int i=0; i<10; i++){
			System.out.println ("Primeiro usuario digite um numero inteiro: ");
			n[i]=sc.nextInt();
		}
		System.out.println ("Segundo usuario digite ate 5 numeros para tentar adivinhar um dos numeros informados pelo primeiro usuario:");
		for (int u=0;u<5;u++){
			x++;
			System.out.println (x + "Tentativa:");
			z=sc.nextInt();
			if (c>1){
				break;
			}
			if (c==0){
				if (x<5){
					System.out.println ("Voce errou tente um outro numero:");
				}
			}
			for (int i=0;i<10;i++){
				if (z==n[i]){
					System.out.println ("Voce acertou.");
					c++;
					break;
				}
			}
		}
		if (c==0){
			System.out.println ("Voce errou todas as suas chances.");
		}
}
}
