package Exercicio21;

import java.util.Random;
import java.util.Scanner;

public class Exercicio21 {

	static int jogardado(){
		Random r = new Random();
		int x = r.nextInt(6);
		return x;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		int nv;
		int v[] = new int[6];
		for (int i=0;i<6;i++){
			v[i]=0;
		}
		System.out.println ("Informe quantas vezes sera jogado os dados: ");
		nv = sc.nextInt();
		for (int i=0;i<nv;i++){
			int r=jogardado ();
			if (r==1){
				v[0]++;
			}
			if (r==2){
				v[1]++;
			}
			if (r==3){
				v[2]++;
			}
			if (r==4){
				v[3]++;
			}
			if (r==5){
				v[4]++;
			}
			if (r==6){
				v[5]++;
			}
		}
		for (int i=0;i<6;i++){
			System.out.println (v[i]);
		}
	}

}
