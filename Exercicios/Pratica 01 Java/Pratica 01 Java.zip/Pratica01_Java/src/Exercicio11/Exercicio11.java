package Exercicio11;

import java.util.Scanner;

public class Exercicio11 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		float n[] = new float[10];
		float soma=0;
		float media;
		
		for (int i=0; i<10; i++){
		System.out.println ("Digite um numero inteiro: ");
		n[i]=sc.nextInt();
		}
		float maior=n[0];
		float menor=n[0];
		for (int i=0; i<10; i++){
			System.out.println ("Os numeros informados foram: " + n[i]);
		}
		for (int i=1; i<10; i++){
			if (maior<n[i]){
				maior=n[i];
			}
			if (n[i]<menor){
				menor=n[i];
			}
			soma=soma+n[i];
		}
		media=soma/10;
		System.out.println ("O maior numero informado e: " + maior);
		System.out.println ("O menor numero informado e: " + menor);
		System.out.println ("A media dos numeros informado e: " + media);
	}

}
