package Exercicio19;

import java.util.Scanner;

public class Exercicio19 {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		double a[] = new double [60];
		int n=0;
		int na=0,nr=0;
		float aa,ar;
		for (int i=0;i<60;i++){
			n++;
			System.out.println ("Informe a nota de aluno de numero "+n+": ");
			a[i]=sc.nextDouble();
			if (a[i]>=60){
				na++;
			}
			if (a[i]<60){
				nr++;
			}
		}
		aa=100/60*na;
		ar=100/60*nr;
		double maior=a[0],menor=a[0];
		
		for (int i=0;i<60;i++){
			if (maior<a[i]){
				maior=a[i];
			}
			if (menor>a[i]){
				menor=a[i];
			}
		}
		System.out.println ("O numero de alunos aprovados e: "+aa);
		System.out.println ("O numero de alunos reprovados e: "+ar);
		System.out.println ("A maior nota e: "+maior);
		System.out.println ("A menor nota e: "+menor);
	}

}
